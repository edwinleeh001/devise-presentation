"""Decode final frames, verify audible tracks, and install the four site assets."""
import hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path
import imageio_ffmpeg
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[1]
SITE=PROJECT/'devise-presentation';OUT=PROJECT/'outputs'/'devise-paper-videos'
ff=imageio_ffmpeg.get_ffmpeg_exe();reports=[]
for n in [1,2]:
 for lang in ['en','zh']:
  key=f'figure-{n}-{lang}';o=OUT/key;p=ROOT/key;video=o/'video.mp4'
  export=json.loads((o/'video.mp4.export.json').read_text());assert export['actual']['duration']==20 and export['decodeVerified'] and export['deterministicSeekVerified']
  result=subprocess.run([ff,'-hide_banner','-i',str(video),'-vn','-af','volumedetect','-f','null','-'],capture_output=True,text=True,check=True)
  mean=float(re.search(r'mean_volume: ([-\d.]+) dB',result.stderr)[1]);peak=float(re.search(r'max_volume: ([-\d.]+) dB',result.stderr)[1]);assert -35<mean<-5 and peak<0,(key,mean,peak)
  cues=json.loads((p/'cues.json').read_text());assert cues[-1]['end']<19.8
  # Inspect encoded scenes and transitions, rather than only the HTML renderer.
  times=sorted(set([0,19.95]+[round(c['start']+min(1.8,c['audioDuration']/2),3) for c in cues]+[round(c['start']-.08,3) for c in cues[1:]]))
  qa=SITE/'qa'/'paper-videos';qa.mkdir(parents=True,exist_ok=True)
  for i,t in enumerate(times):subprocess.run([ff,'-y','-loglevel','error','-ss',str(t),'-i',str(video),'-frames:v','1',str(qa/f'decoded-{key}-{i}.png')],check=True)
  posterTime=cues[2 if n==1 else 1]['start']+1.9
  subprocess.run([ff,'-y','-loglevel','error','-ss',str(posterTime),'-i',str(video),'-frames:v','1','-q:v','2',str(o/'poster.jpg')],check=True)
  base=SITE/'public'/'media'/f'devise-figure-{n}-{lang}'
  for src,extension in [('video.mp4','.mp4'),('poster.jpg','.jpg'),('subtitles.srt','.srt'),('subtitles.vtt','.vtt')]:shutil.copy2(o/src,str(base)+extension)
  reports.append({'clip':key,'seconds':20,'width':1920,'height':1080,'fps':24,'audio':'AAC, 48 kHz, stereo','meanVolumeDb':mean,'peakVolumeDb':peak,'lastSpeechEnd':cues[-1]['end'],'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'encodedFramesCheckedAt':times,'tts':json.loads((p/'tts-report.json').read_text()),'export':export})
report={'clips':reports,'sources':{'paper':'Frome et al., DeViSE: A Deep Visual-Semantic Embedding Model, NIPS 2013','figure1':'User-supplied original Figure 1, paper p.3','figure2':'User-supplied original Figure 2, paper p.6; interpretation from section 4.2 p.7','animationSha256':hashlib.sha256((ROOT/'animation.js').read_bytes()).hexdigest()},'checks':['All four MP4s decode fully with audible, unclipped tracks.','480 frames each; exactly 20 seconds; deterministic seeking.','Original ranks and diagrams retained; no generated scientific evidence.','Sentence subtitles use measured audio durations.'],'limitations':['Narration is synthesized, not a human recording.','No human listening review is claimed; audio presence, levels, timing and sentence completion were verified.'],'costs':{'modelTokens':None,'ttsPrice':None}}
(SITE/'qa'/'paper-videos'/'production-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
readme='''# DeViSE — original Figure 1 and Figure 2 videos

Four final MP4s: 20.000 seconds each, 1920 × 1080, 24 fps, H.264 / AAC stereo 48 kHz. Narration: Microsoft Edge online neural TTS, edge-tts 7.3.1; English AndrewMultilingualNeural, Chinese XiaoxiaoNeural; normal rate +0%. Complete sentences are synthesized, then placed on measured timelines with deliberate 0.35–0.6 second gaps. Nothing is time-compressed or cut mid-sentence. Sentence-level subtitles, not word-level timestamps, match the measured WAV lengths. Narration is synthetic. No human listening review is claimed.

The PNGs are the unmodified original paper figures supplied by the user. SVG viewports zoom into the original pixels; outlines and traces are authored teaching annotations. Figure 1B shows text-label embeddings, not projected test images or accuracy. Figure 2 preserves decreasing-score ranks and bold exact matches; DeViSE+1K uses the 2011 ImageNet 21K label set, versus softmax’s 1K output labels. Both were trained on ILSVRC 2012 1K. The lens is fourth; both miss the exact salad-bar label; the paper describes softmax’s spacecraft labels as more nearly correct. Selected examples do not establish overall accuracy. No numerical scores are invented.

Source: Frome et al., *DeViSE: A Deep Visual-Semantic Embedding Model*, NIPS 2013, Figure 1 p.3, Figure 2 p.6, section 4.2 p.7. https://papers.nips.cc/paper/2013/hash/7cce53cf90577442771720a370c3c723-Abstract.html
TTS client: https://github.com/rany2/edge-tts

## Re-export using the included audio

Requires Node.js, Playwright/Chromium, Python with imageio-ffmpeg, and FFmpeg. Keep the archive directory structure. Serve the HTML directly for an interactive timestamp preview (`window.renderAt(t)`). For a final export from the extracted archive root:

    node work/devise-paper-videos/export-video.mjs --html work/devise-paper-videos/figure-1-en.html --out recreated-figure-1-en.mp4 --audio work/devise-paper-videos/figure-1-en/narration.wav --width 1920 --height 1080 --fps 24 --ffmpeg /path/to/ffmpeg

Set NODE_PATH to the installed Playwright package directory if needed. Substitute figure-1-zh, figure-2-en or figure-2-zh for the other versions. The exporter uses an isolated, unsigned-in Chromium, blocks external requests, checks arbitrary-order seeking, renders every frame, encodes fast-start MP4 and verifies full decoding. Actual synthesis/render times and sound levels are in production-report.json; unavailable costs/token usage are recorded as null. No credentials or intermediate frame directories are included.

For fresh narration, install edge-tts==7.3.1 and its dependencies in a virtual environment, run make-audio.py, then build-timelines.py in the original workspace. They retain sentence audio, boundary events, cue data, scripts and measured durations. build-timelines.py expects the original images under devise-presentation/public/media/originals/ and writes site transcript data under devise-presentation/src/content/.
'''
(OUT/'README.md').write_text(readme)
sourceFiles=[p for p in ROOT.rglob('*') if p.is_file() and 'dependencies' not in p.parts and '__pycache__' not in p.parts and p.name!='preview-audio.wav']
zipPath=SITE/'public'/'sources'/'paper-figure-videos-source.zip'
with zipfile.ZipFile(zipPath,'w',zipfile.ZIP_DEFLATED) as archive:
 for p in sourceFiles:archive.write(p,p.relative_to(PROJECT))
 archive.write(OUT/'README.md','README.md');archive.write(SITE/'qa'/'paper-videos'/'production-report.json','production-report.json')
 for key in [f'figure-{n}-{lang}' for n in [1,2] for lang in ['en','zh']]:
  for name in ['storyboard.json','narration.txt','subtitles.srt','subtitles.vtt']:archive.write(OUT/key/name,f'outputs/{key}/{name}')
print(json.dumps({'clips':len(reports),'sourcePackBytes':zipPath.stat().st_size,'audioLevels':[{'clip':r['clip'],'mean':r['meanVolumeDb'],'peak':r['peakVolumeDb']} for r in reports]},indent=2))
