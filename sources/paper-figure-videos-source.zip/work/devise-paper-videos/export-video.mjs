#!/usr/bin/env node
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile, access, mkdir, mkdtemp, rm, rename, writeFile, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { randomUUID, createHash } from 'node:crypto';

const help = `Deterministic local HTML animation → MP4
Required: --html FILE --out FILE
Options: --audio FILE --ffmpeg BIN --width 1920 --height 1080 --fps 24
         --start 0 --duration SECONDS --browser-executable BIN
         --playwright-module PATH --keep-frames --overwrite
HTML contract: window.videoDuration (seconds), async window.renderAt(t).
NODE_PATH may point to the desktop bundled Node packages.
Audio must already be aligned/mixed; subtitles must be rendered by the HTML.`;

function args(argv) {
  const valueKeys = new Set(['html','out','audio','ffmpeg','width','height','fps','start','duration','browser-executable','playwright-module']);
  const flags = new Set(['keep-frames','overwrite']);
  const a = {};
  for (let i=0;i<argv.length;i++) {
    const key=argv[i].replace(/^--/,'');
    if (!argv[i].startsWith('--')) throw new Error(`Unexpected argument: ${argv[i]}`);
    if (flags.has(key)) a[key]=true;
    else if (valueKeys.has(key) && argv[i+1] && !argv[i+1].startsWith('--')) a[key]=argv[++i];
    else throw new Error(`Unknown option or missing value: --${key}`);
  }
  if (!a.html || !a.out) throw new Error(help);
  for (const [key,def] of Object.entries({width:1920,height:1080,fps:24,start:0})) {
    a[key]=Number(a[key]??def);
    if (!Number.isFinite(a[key])) throw new Error(`Invalid ${key}`);
  }
  if (a.start<0 || a.fps<=0 || a.fps>120) throw new Error('start must be ≥0; fps must be in (0,120].');
  if (![a.width,a.height].every(n=>Number.isInteger(n)&&n>=2&&n%2===0)) throw new Error('Dimensions must be positive even integers.');
  if (a.duration!==undefined) {
    a.duration=Number(a.duration);
    if (!(a.duration>0) || !Number.isFinite(a.duration)) throw new Error('duration must be finite and positive.');
  }
  a.html=path.resolve(a.html); a.out=path.resolve(a.out);
  if (a.audio) a.audio=path.resolve(a.audio);
  if (path.extname(a.out).toLowerCase()!=='.mp4') throw new Error('Output must have an .mp4 extension.');
  if (a.out===a.html || a.out===a.audio) throw new Error('Output cannot replace an input.');
  return a;
}

function ffmpeg(bin, argv, {allowFailure=false}={}) {
  const result=spawnSync(bin,argv,{encoding:'utf8',maxBuffer:16*1024*1024});
  if (result.error) throw result.error;
  if (!allowFailure && result.status!==0) throw new Error(`FFmpeg failed (${result.status}):\n${result.stderr.slice(-5000)}`);
  return result;
}

function mediaInfo(bin,file) {
  const r=ffmpeg(bin,['-hide_banner','-i',file],{allowFailure:true});
  const match=r.stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  if (!match) throw new Error(`Cannot read media duration: ${file}`);
  return {duration:Number(match[1])*3600+Number(match[2])*60+Number(match[3]),
    video:r.stderr.split('\n').find(line=>/Stream.*Video:/.test(line))?.trim()??null,
    audio:r.stderr.split('\n').find(line=>/Stream.*Audio:/.test(line))?.trim()??null};
}

async function locateFFmpeg(a) {
  if (a.ffmpeg || process.env.FFMPEG_BIN) return a.ffmpeg||process.env.FFMPEG_BIN;
  if (spawnSync('ffmpeg',['-version'],{stdio:'ignore'}).status===0) return 'ffmpeg';
  const localPython='/Users/macbook/Documents/Codex/tools/teaching-video/.venv/bin/python';
  if (existsSync(localPython)) {
    const r=spawnSync(localPython,['-c','import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())'],{encoding:'utf8'});
    if (r.status===0 && existsSync(r.stdout.trim())) return r.stdout.trim();
  }
  throw new Error('FFmpeg unavailable. Supply --ffmpeg or see references/export.md.');
}

async function serve(root) {
  const types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.woff2':'font/woff2','.wav':'audio/wav'};
  const server=createServer(async(req,res)=>{
    try {
      const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
      const file=path.resolve(root,'.'+pathname);
      if (file!==root && !file.startsWith(root+path.sep)) {res.writeHead(403).end();return;}
      const content=await readFile(file);
      res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'}).end(content);
    } catch {res.writeHead(404).end();}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  return {server,origin:`http://127.0.0.1:${server.address().port}`};
}

async function main() {
  if (process.argv.includes('--help')) {console.log(help);return;}
  const a=args(process.argv.slice(2));
  await access(a.html);
  if (a.audio) await access(a.audio);
  if (!a.overwrite && existsSync(a.out)) throw new Error('Output exists. Choose another name or explicitly use --overwrite.');
  const bin=await locateFFmpeg(a);
  ffmpeg(bin,['-version']);
  const require=createRequire(import.meta.url);
  let chromium;
  try {({chromium}=require(a['playwright-module']||'playwright'));}
  catch {throw new Error('Playwright unavailable. Set NODE_PATH to the desktop package directory or pass --playwright-module.');}
  await mkdir(path.dirname(a.out),{recursive:true});
  const scratch=path.resolve('work');
  await mkdir(scratch,{recursive:true});
  const frames=await mkdtemp(path.join(scratch,'teaching-video-frames-'));
  const temporary=path.join(path.dirname(a.out),`.teaching-video-${randomUUID()}.mp4`);
  let browser,server;
  const began=Date.now();
  try {
    const hosted=await serve(path.dirname(a.html)); server=hosted.server;
    const chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
    const executable=a['browser-executable']||(existsSync(chrome)?chrome:undefined);
    browser=await chromium.launch({headless:true,executablePath:executable});
    const context=await browser.newContext({viewport:{width:a.width,height:a.height},deviceScaleFactor:1});
    const page=await context.newPage();
    const pageErrors=[];
    page.on('pageerror',e=>pageErrors.push(e.message));
    await context.route('**/*',route=>{
      const url=route.request().url();
      if (url.startsWith(hosted.origin+'/') || url.startsWith('data:') || url.startsWith('blob:')) return route.continue();
      return route.abort();
    });
    await page.goto(hosted.origin+'/'+encodeURIComponent(path.basename(a.html)),{waitUntil:'load'});
    await page.evaluate(async()=>{
      await document.fonts.ready;
      await Promise.all([...document.images].map(i=>i.decode()));
      if (typeof window.renderAt!=='function') throw new Error('HTML must define window.renderAt(t).');
    });
    const whole=await page.evaluate(()=>window.videoDuration);
    if (!Number.isFinite(whole)||whole<=0) throw new Error('HTML must define positive window.videoDuration.');
    const duration=a.duration??(whole-a.start);
    if (duration<=0 || a.start+duration>whole+0.001) throw new Error('Requested interval exceeds videoDuration.');
    const frameCount=Math.ceil(duration*a.fps);
    const encodedDuration=frameCount/a.fps;
    const inputAudio=a.audio?mediaInfo(bin,a.audio):null;
    if (inputAudio && !inputAudio.audio) throw new Error('Input has no audio stream.');
    if (inputAudio && inputAudio.duration>encodedDuration+0.25) throw new Error(`Audio (${inputAudio.duration}s) exceeds video (${encodedDuration}s). Fix the timeline instead of clipping narration.`);
    const render=async t=>{await page.evaluate(async t=>window.renderAt(t),t);if(pageErrors.length)throw new Error(pageErrors.join('\n'));};
    // Forward/backward seeking must restore the same frame before a long render.
    const middle=a.start+duration/2;
    await render(middle);
    const first=await page.screenshot({type:'png'});
    await render(Math.max(a.start,a.start+duration-1/a.fps));
    await render(middle);
    const second=await page.screenshot({type:'png'});
    if (!first.equals(second)) throw new Error('renderAt is not deterministic when seeking backward. Remove autonomous animation/state accumulation.');
    for(let i=0;i<frameCount;i++) {
      await render(a.start+i/a.fps);
      await page.screenshot({path:path.join(frames,`frame-${String(i).padStart(6,'0')}.png`),type:'png'});
      if(i===0 || (i+1)%(a.fps*10)===0 || i===frameCount-1) console.log(`Rendered ${i+1}/${frameCount} frames`);
    }
    await browser.close();browser=null;
    const cmd=['-hide_banner','-loglevel','error','-nostdin','-n','-framerate',String(a.fps),'-start_number','0','-i',path.join(frames,'frame-%06d.png')];
    if(a.audio)cmd.push('-i',a.audio);
    cmd.push('-map','0:v:0');
    if(a.audio)cmd.push('-map','1:a:0','-af','apad','-c:a','aac','-b:a','192k','-ar','48000','-ac','2');
    cmd.push('-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-t',String(encodedDuration),'-movflags','+faststart',temporary);
    ffmpeg(bin,cmd);
    ffmpeg(bin,['-hide_banner','-loglevel','error','-nostdin','-i',temporary,'-map','0:v:0','-map','0:a?','-f','null','-']);
    const actual=mediaInfo(bin,temporary);
    if(!actual.video || !actual.video.includes('h264') || !actual.video.includes(`${a.width}x${a.height}`))throw new Error('Unexpected output codec or dimensions.');
    if(a.audio && !actual.audio?.includes('aac'))throw new Error('Output lacks expected AAC audio.');
    if(Math.abs(actual.duration-encodedDuration)>0.15)throw new Error('Unexpected output duration.');
    const videoBytes=(await stat(temporary)).size;
    const sourceHash=createHash('sha256').update(await readFile(a.html)).digest('hex');
    if(!a.overwrite && existsSync(a.out))throw new Error('Output was created by another process; refusing to replace it.');
    await rename(temporary,a.out);
    const report={output:a.out,source:a.html,sourceSha256:sourceHash,start:a.start,requestedDuration:duration,encodedDuration,fps:a.fps,width:a.width,height:a.height,frames:frameCount,audioInput:a.audio??null,audioInputDuration:inputAudio?.duration??null,actual,decodeVerified:true,deterministicSeekVerified:true,bytes:videoBytes,elapsedSeconds:(Date.now()-began)/1000,...(a['keep-frames']?{frameDirectory:frames}:{})};
    await writeFile(a.out+'.export.json',JSON.stringify(report,null,2)+'\n');
    console.log(JSON.stringify(report,null,2));
  } finally {
    if(browser)await browser.close();
    if(server)await new Promise(resolve=>server.close(resolve));
    await rm(temporary,{force:true});
    if(!a['keep-frames'])await rm(frames,{recursive:true,force:true});
  }
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
