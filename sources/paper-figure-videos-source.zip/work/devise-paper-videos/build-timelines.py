"""Place untouched sentence audio on a measured, paused 20-second timeline."""
from pathlib import Path
import json,subprocess,wave,shutil
import imageio_ffmpeg
ROOT=Path(__file__).resolve().parent
SITE=ROOT.parents[1]/'devise-presentation'
OUT=ROOT.parents[1]/'outputs'/'devise-paper-videos'
ff=imageio_ffmpeg.get_ffmpeg_exe()
scripts=json.loads((ROOT/'scripts.json').read_text())
def timestamp(t,sep=','):
 ms=round(t*1000)
 return f'{ms//3600000:02d}:{ms//60000%60:02d}:{ms//1000%60:02d}{sep}{ms%1000:03d}'
report=[];siteData={}
for number in [1,2]:
 siteData[number]={}
 shutil.copy2(SITE/'public'/'media'/'originals'/f'devise-figure-{number}.png',ROOT/f'original-{number}.png')
 for lang in ['en','zh']:
  key=f'figure-{number}-{lang}';p=ROOT/key;o=OUT/key;o.mkdir(parents=True,exist_ok=True)
  sentences=scripts[str(number)][lang];gaps=[.45,.5,.6,0] if number==1 else [.35,.4,.4,.45,0]
  cues=[];cursor=.25
  for i,text in enumerate(sentences):
   target=p/'audio'/f'{i}.wav'
   subprocess.run([ff,'-y','-loglevel','error','-i',str(p/'audio'/f'{i}.mp3'),'-ar','48000','-ac','2',str(target)],check=True)
   with wave.open(str(target)) as w:duration=w.getnframes()/w.getframerate()
   cues.append({'id':f'figure-{number}-cue-{i+1}','scene':i,'start':round(cursor,4),'end':round(cursor+duration,4),'en':scripts[str(number)]['en'][i].replace('Devise','DeViSE'),'zh':scripts[str(number)]['zh'][i],'spokenText':text,'audio':f'{key}/audio/{i}.wav','audioDuration':duration,'pauseAfter':gaps[i],'action':scripts[str(number)]['actions'][i]})
   cursor+=duration+gaps[i]
  assert cursor<19.8,(key,cursor,'Revise the script; never cut or speed up speech.')
  (p/'cues.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2));(o/'storyboard.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2))
  args=[ff,'-y','-loglevel','error']
  for i in range(len(cues)):args+=['-i',str(p/'audio'/f'{i}.wav')]
  filters=[f'[{i}:a]adelay={round(c["start"]*1000)}|{round(c["start"]*1000)}[a{i}]' for i,c in enumerate(cues)]
  filters+=[''.join(f'[a{i}]' for i in range(len(cues)))+f'amix=inputs={len(cues)}:duration=longest:normalize=0,apad,atrim=duration=20[out]']
  args+=['-filter_complex',';'.join(filters),'-map','[out]',str(p/'narration.wav')];subprocess.run(args,check=True)
  srt='\n\n'.join(f'{i+1}\n{timestamp(c["start"])} --> {timestamp(c["end"])}\n{c[lang]}' for i,c in enumerate(cues))+'\n'
  (o/'subtitles.srt').write_text(srt)
  (o/'subtitles.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(f'{i+1}\n{timestamp(c["start"],".")} --> {timestamp(c["end"],".")}\n{c[lang]}' for i,c in enumerate(cues))+'\n')
  (o/'narration.txt').write_text('\n\n'.join(c[lang] for c in cues)+'\n')
  subprocess.run([ff,'-y','-loglevel','error','-i',str(p/'narration.wav'),'-t','3.9',str(p/'preview-audio.wav')],check=True)
  config={'figure':number,'language':lang,'cues':cues,'timing':[round(c['start']-.15,4) for c in cues[1:]]}
  html=(ROOT/'template.html').read_text().replace('/* CONFIG */', 'window.CONFIG='+json.dumps(config,ensure_ascii=False)+';')
  (ROOT/f'{key}.html').write_text(html)
  siteData[number][lang]={'transcript':' '.join(c[lang] for c in cues)}
  report.append({'clip':key,'lastSpeechEnd':cues[-1]['end'],'pauses':gaps,'tailHold':round(20-cursor,3),'duration':20})
(SITE/'src'/'content'/'paper-video-scripts.json').write_text(json.dumps(siteData,ensure_ascii=False,indent=2)+'\n')
(ROOT/'timing-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
