const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const root=__dirname,qa=path.resolve('devise-presentation/qa/paper-videos');fs.mkdirSync(qa,{recursive:true});
(async()=>{
 const server=http.createServer((req,res)=>{const file=path.join(root,decodeURIComponent(new URL(req.url,'http://localhost').pathname));try{const data=fs.readFileSync(file);res.setHeader('Content-Type',file.endsWith('.html')?'text/html':file.endsWith('.js')?'text/javascript':file.endsWith('.png')?'image/png':'application/octet-stream');res.end(data)}catch{res.writeHead(404).end()}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}),page=await browser.newPage({viewport:{width:1920,height:1080}}),errors=[],records=[];
 page.on('pageerror',e=>errors.push(e.message));
 for(const number of [1,2])for(const lang of ['en','zh']){
  await page.goto(`http://127.0.0.1:${server.address().port}/figure-${number}-${lang}.html`);
  await page.evaluate(()=>document.fonts.ready);
  const cues=JSON.parse(fs.readFileSync(path.join(root,`figure-${number}-${lang}/cues.json`))),times=[0,...cues.map(c=>c.start+Math.min(.9,(c.end-c.start)/2)),19.95,...cues.slice(1).map(c=>c.start+Math.min(2.1,c.end-c.start-.2))];
  for(let i=0;i<times.length;i++){
   await page.evaluate(t=>window.renderAt(t),times[i]);
   const overflow=await page.evaluate(()=>[...document.querySelectorAll('text')].filter(e=>{const r=e.getBoundingClientRect();return r.left<0||r.top<0||r.right>1920.1||r.bottom>1080.1}).map(e=>e.textContent));
   records.push({number,lang,t:times[i],overflow});await page.screenshot({path:path.join(qa,`figure-${number}-${lang}-${i}.png`)});
  }
 }
 await browser.close();await new Promise(r=>server.close(r));
 fs.writeFileSync(path.join(qa,'animation-inspection.json'),JSON.stringify({records,errors},null,2));
 if(errors.length||records.some(r=>r.overflow.length))throw Error(JSON.stringify({errors,overflow:records.filter(r=>r.overflow.length)}));
 console.log(`Captured ${records.length} full-resolution scene/end frames; no text overflow or runtime errors.`);
})().catch(e=>{console.error(e);process.exit(1)});
