"""Synthesize complete sentences; keep actual audio and service boundary events."""
import asyncio,json,time,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'dependencies'))
import edge_tts

ROOT=Path(__file__).resolve().parent
SCRIPTS={
 1:{
  'en':["How does Devise connect vision and language?","It combines a pretrained visual network with fixed word embeddings.","A learned projection aligns images with label vectors.","Panel B shows semantic neighborhoods among labels, not image predictions."],
  'zh':['DeViSE 如何连接视觉与语言？','它结合预训练视觉网络，与固定的词向量。','学习一个投影，让图像对齐标签向量。','B 图展示标签之间的语义邻域，不是图像预测结果。'],
  'actions':['Reveal the unchanged original Figure 1 and identify panels A and B.','Zoom to panel A; outline the two pretrained lower-layer sources and their initialization arrows.','Zoom to the central joint model; trace the visual-core → transformation → similarity path and the fixed label-vector branch.','Zoom to the original panel B scatter plot; identify label neighborhoods, with a persistent caution that these are text embeddings.']},
 2:{
  'en':["Can Devise recognize unseen classes?","Here, the correct lens label ranks fourth.","But both models miss the salad bar.","For the spacecraft, softmax gives more relevant suggestions.","They show strengths and limits, not overall accuracy."],
  'zh':['模型能识别未见类别吗？','镜头的正确标签，排第四。','沙拉吧，两个模型都没命中。','而飞船，softmax 的预测更相关。','案例展示优点与局限，不代表总体准确率。'],
  'actions':['Reveal the unchanged original Figure 2, its six selected examples, and the different candidate label sets.','Zoom to original example A; trace the author’s ranked list down to the bold correct lens label at rank four.','Zoom to original example E; show both original top-five lists and the absent exact salad-bar label.','Zoom to original example F; outline the softmax list, reflecting the authors’ more-nearly-correct assessment.','Return to the original six-case overview, retaining the evidence limitations rather than inventing an accuracy score.']}
}
async def clip(number,language):
 p=ROOT/f'figure-{number}-{language}';(p/'audio').mkdir(parents=True,exist_ok=True)
 voice='en-US-AndrewMultilingualNeural' if language=='en' else 'zh-CN-XiaoxiaoNeural'
 began=time.monotonic();generated=0
 for i,text in enumerate(SCRIPTS[number][language]):
  target=p/'audio'/f'{i}.mp3'
  if target.exists() and target.stat().st_size>1000:continue
  events=[]
  with target.open('wb') as f:
   async for chunk in edge_tts.Communicate(text,voice,rate='+0%').stream():
    if chunk['type']=='audio':f.write(chunk['data'])
    else:events.append(chunk)
  (p/'audio'/f'{i}.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
  generated+=1
 if generated:
  old=json.loads((p/'tts-report.json').read_text()) if (p/'tts-report.json').exists() else {}
  (p/'tts-report.json').write_text(json.dumps({'provider':'Microsoft Edge online TTS via edge-tts','clientVersion':edge_tts.__version__,'voice':voice,'rate':'+0%','elapsedSeconds':old.get('elapsedSeconds',0)+time.monotonic()-began,'humanListeningReview':False},indent=2))
 print(f'Figure {number} {language}: synthesized {len(SCRIPTS[number][language])} complete sentences',flush=True)
async def main():
 (ROOT/'scripts.json').write_text(json.dumps(SCRIPTS,ensure_ascii=False,indent=2))
 # Two independent voices can run concurrently; each voice keeps its sentence order.
 for n in [1,2]:await asyncio.gather(clip(n,'en'),clip(n,'zh'))
if __name__=='__main__':asyncio.run(main())
