/* Absolute-time SVG annotation of unmodified, locally supplied paper figures. */
const {figure:N,language:L,cues:CUES,timing:TIMING}=window.CONFIG,zh=L==='zh';
document.documentElement.lang=zh?'zh-CN':'en';
const stage=document.getElementById('stage'),ink='#073b3d',teal='#078c87',gold='#c18526',muted='#627d78';
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const tr=(en,cn)=>zh?cn:en,clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},reveal=(t,a,d=.6)=>ease((t-a)/d);
const text=(x,y,s,size=32,color=ink,extra='')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" ${extra}>${esc(s)}</text>`;
const box=(x,y,w,h,fill='#fff',stroke='none',r=16)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="${stroke}" stroke-width="3"/>`;
const group=(alpha,body,dx=0,dy=0)=>`<g opacity="${alpha}" transform="translate(${dx} ${dy})">${body}</g>`;
function crop(v,x,y,w,h){
 const [vx,vy,vw,vh]=v,s=Math.min(w/vw,h/vh),ox=x+(w-vw*s)/2,oy=y+(h-vh*s)/2;
 return {x:ox,y:oy,s,source:`<svg x="${ox}" y="${oy}" width="${vw*s}" height="${vh*s}" viewBox="${v.join(' ')}"><image href="original-${N}.png" width="${N===1?2692:2702}" height="${N===1?1092:1258}"/></svg>`,point:(a,b)=>[ox+(a-vx)*s,oy+(b-vy)*s],rect:(a,b,c,d)=>[ox+(a-vx)*s,oy+(b-vy)*s,c*s,d*s]};
}
function outline(p,rect,alpha=1,color=teal){return group(alpha,box(...p.rect(...rect),'none',color,8))}
function trace(p,coords,progress,color=gold){const points=coords.map(([x,y])=>p.point(x,y));return `<polyline points="${points.map(q=>q.join(',')).join(' ')}" fill="none" stroke="${color}" stroke-width="6" stroke-linecap="round" pathLength="1" stroke-dasharray="${progress} 1"/>`}
function heading(title,subtitle){return text(90,83,`DeViSE / FIGURE ${N}`,34,ink,'font-weight="700"')+text(1830,79,'FROME ET AL. · NIPS 2013',23,muted,'text-anchor="end"')+text(90,149,title,48,ink,'font-weight="700"')+text(92,190,subtitle,25,muted)}
function tag(x,y,label,color=teal,w=550){return box(x,y,w,58,color===teal?'#e4f0e9':'#f4ecd7','none',12)+text(x+24,y+39,label,27,color,'font-weight="600"')}
function captionLines(s){
 const max=zh?28:76,words=zh?[...s]:s.split(' '),lines=[];let line='';
 for(const word of words){const next=line+(line&&!zh?' ':'')+word;if(next.length>max&&line){lines.push(line);line=word}else line=next}if(line)lines.push(line);return lines;
}
function footer(t){const cue=CUES.find(c=>t>=c.start&&t<c.end);let result=text(90,899,tr(`Original Figure ${N} · annotated teaching excerpt · no invented data`,`论文原始 Figure ${N} · 教学标注与局部放大 · 未编造数据`),22,muted);
 result+=box(90,931,1740,117,ink,'none',16);const lines=captionLines(cue?.[L]||'');lines.forEach((line,i)=>{result+=text(960,lines.length===1?1003:981+i*45,line,34,'#fff','text-anchor="middle"')});
 return result+box(0,1069,1920*t/20,11,teal,'none',0);
}
function figure1(scene,t){
 if(scene===0){const p=crop([0,0,2692,1092],90,222,1740,626);return heading(tr('Where vision meets language','视觉与语言，如何相遇？'),tr('A: model architecture.  B: semantic structure in text.','A：模型架构。B：文本中的语义结构。'))+box(90,215,1740,640)+p.source}
 if(scene===1){const p=crop([130,95,1600,640],95,248,1320,565);let body=heading(tr('Start with two pretrained representations','从两种预训练表示出发'),tr('The lower layers initialize the joint model.','两侧模型的底层参数，用来初始化联合模型。'))+box(90,215,1740,640)+p.source;
  body+=outline(p,[274,407,200,198],reveal(t,.15))+outline(p,[1448,440,225,143],reveal(t,.65));
  body+=trace(p,[[522,511],[704,511]],reveal(t,1.1,1.2))+trace(p,[[1425,511],[1230,511]],reveal(t,1.45,1.2));
  body+=group(reveal(t,.3),text(1460,333,tr('VISION','视觉网络'),24,muted)+text(1460,385,tr('Pretrained CNN','预训练 CNN'),33,ink,'font-weight="700"')+text(1460,493,tr('LANGUAGE','语言表示'),24,muted)+text(1460,545,tr('Fixed word vectors','固定词向量'),31,ink,'font-weight="700"')+text(1460,676,tr('Reuse lower layers','复用底层参数'),28,teal)+text(1460,725,tr('→ joint model','→ 联合模型'),30,teal));return body;
 }
 if(scene===2){const p=crop([715,110,495,585],95,222,915,620);let body=heading(tr('Learn a projection into label space','学习投影，对齐标签空间'),tr('A learned transformation connects visual features to text embeddings.','学习变换层，将视觉特征连接到文本词向量。'))+box(90,215,1740,640)+p.source;
  body+=outline(p,[716,332,247,57],reveal(t,.1))+outline(p,[974,440,220,146],reveal(t,.65));
  body+=trace(p,[[838,414],[838,385]],reveal(t,.4,.6))+trace(p,[[838,335],[881,284]],reveal(t,1.05,1.0))+trace(p,[[1068,443],[1004,286]],reveal(t,1.25,1.6),teal);
  body+=group(reveal(t,.25),text(1060,324,tr('Learned projection','学习得到的投影'),34,ink,'font-weight="700"')+text(1060,402,'z = Mv(x)',59,teal,'class="math"')+text(1060,514,tr('Fixed label vectors','固定的标签向量'),34,ink,'font-weight="700"')+text(1060,584,'tᵧ',58,teal,'class="math"'));
  body+=group(reveal(t,1.8),tag(1060,689,tr('Similarity ranks candidate labels','相似度决定候选标签排序'),teal,700));return body;
 }
 const p=crop([1740,0,910,790],100,221,1010,625);let body=heading(tr('Panel B: semantic neighborhoods','B 图：标签的语义邻域'),tr('The authors’ t-SNE visualization of skip-gram label embeddings.','作者对 skip-gram 标签词向量进行的 t-SNE 可视化。'))+box(90,215,1740,640)+p.source;
 const clusters=[[1900,432,81],[2400,366,64],[2390,206,51]];
 clusters.forEach(([x,y,r],i)=>{const [cx,cy]=p.point(x,y),a=reveal(t,.35+i*.6);body+=`<circle cx="${cx}" cy="${cy}" r="${r*p.s}" fill="none" stroke="${teal}" stroke-width="4" opacity="${a}"/>`});
 body+=group(reveal(t,.25),text(1160,334,tr('Nearby meanings','含义相近'),40,ink,'font-weight="700"')+text(1160,395,tr('form neighborhoods','形成语义邻域'),36,ink)+text(1160,492,tr('Dogs · birds · instruments','狗 · 鸟 · 乐器'),31,teal)+text(1160,558,tr('Each dot is a label vector.','每个点代表一个标签词向量。'),29,muted));
 body+=group(reveal(t,1.6),tag(1160,659,tr('Text embeddings, not image results','词向量，不是图像预测结果'),gold,600)+text(1160,766,tr('2D distances are not prediction scores.','二维距离不等于预测得分。'),25,muted));return body;
}
function comparisons(p,scene,t){let result='';
 if(scene===1){const begin=178,dy=35,progress=reveal(t,.3,1.35)*3;
  for(let i=0;i<5;i++){const [x,y]=p.point(296,begin+dy*i),active=i<=progress+.02;result+=`<circle cx="${x}" cy="${y}" r="13" fill="${i===3&&active?teal:active?gold:'#d4dfd9'}"/>`}
  result+=outline(p,[314,265,478,40],reveal(t,1.3));result+=group(reveal(t,1.4),tag(405,679,tr('Exact label: rank 4','准确标签：第 4 名'),teal,615));
 }else if(scene===2){result+=group(reveal(t,.5),tag(402,680,tr('No exact salad-bar match','未命中“沙拉吧”准确标签'),gold,620)+tag(1120,680,tr('No exact salad-bar match','未命中“沙拉吧”准确标签'),gold,620));
 }else{result+=outline(p,[2140,601,549,189],reveal(t,.5),gold)+group(reveal(t,.8),tag(400,680,tr('Softmax is more nearly correct here','本例中，softmax 更接近正确答案'),gold,1330));}
 return result;
}
function figure2(scene,t){
 if(scene===0){const p=crop([0,0,2702,1258],90,218,1740,626);return heading(tr('Can unseen classes be recognized?','未见类别，能被识别吗？'),tr('Selected qualitative examples: six images, two models.','作者选取的定性示例：六张图像，两个模型。'))+box(90,215,1740,640)+p.source}
 if(scene===4){const p=crop([0,0,2702,810],90,213,1740,477);let body=heading(tr('Read the strengths and the limits','看懂优点，也看清边界'),tr('Selected examples cannot estimate overall accuracy.','精选案例不能用来估算总体准确率。'))+box(90,215,1740,640)+p.source;
  const items=[[tr('A · A correct unseen label','A · 命中未见标签'),tr('Lens: rank 4','镜头：第 4 名'),teal],[tr('E · A related error','E · 语义相关的错误'),tr('Salad bar: both miss','沙拉吧：两个模型均未命中'),gold],[tr('F · A counterexample','F · 对优势的反例'),tr('Softmax is more relevant','Softmax 的预测更相关'),gold]];
  items.forEach(([title,sub,color],i)=>body+=group(reveal(t,.15+i*.3),box(108+i*568,708,548,125,color===teal?'#e4f0e9':'#f4ecd7')+text(130+i*568,755,title,29,color,'font-weight="700"')+text(130+i*568,804,sub,26,ink)));return body;
 }
 const rects=[[35,135,1320,225],[1390,355,1300,225],[1390,580,1300,230]],labels=[tr('A · telephoto lens','A · 长焦镜头'),tr('E · salad bar','E · 沙拉吧'),tr('F · spacecraft','F · 航天器')],subs=[tr('The author’s bold label is fourth in the top-five list.','原文粗体准确标签，位于前五名列表的第 4 位。'),tr('Related food terms do not equal an exact prediction.','相关食物词汇，并不等于命中准确标签。'),tr('The paper judges softmax to be more nearly correct in this case.','论文认为，本例的 softmax 预测更接近正确答案。')];
 const p=crop(rects[scene-1],95,313,1730,342);let body=heading(labels[scene-1],subs[scene-1])+box(90,215,1740,640)+text(413,271,tr('DeViSE+1K · 21K candidates','DeViSE+1K · 21K 候选标签'),28,teal,'font-weight="700"')+text(1135,271,tr('Softmax · 1K candidates','Softmax · 1K 候选标签'),28,muted,'font-weight="700"')+p.source+comparisons(p,scene,t);
 return body+text(114,813,tr('Both trained on ImageNet 1K. Original ranks are preserved; scores are not provided.','两者都在 ImageNet 1K 训练。保留原始排名；原图未提供数值得分。'),24,muted);
}
function renderScene(scene,t){return N===1?figure1(scene,t):figure2(scene,t)}
window.videoDuration=20;
window.renderAt=async time=>{
 const t=Math.max(0,Math.min(20,time));let scene=TIMING.filter(s=>t>=s).length;
 const start=scene===0?0:TIMING[scene-1],local=t-start;let content=renderScene(scene,local);
 if(scene>0&&local<.38){const alpha=ease(local/.38),previousStart=scene===1?0:TIMING[scene-2];content=group(1-alpha,renderScene(scene-1,t-previousStart))+group(alpha,content)}
 stage.innerHTML=`<rect width="1920" height="1080" fill="#f7f7ef"/>`+content+footer(t);
 await Promise.all([...stage.querySelectorAll('image')].map(async element=>{const image=new Image();image.src=element.getAttribute('href');await image.decode()}));
};window.renderAt(0);
