# DeViSE — original Figure 1 and Figure 2 videos

Four final MP4s: 20.000 seconds each, 1920 × 1080, 24 fps, H.264 / AAC stereo 48 kHz. Narration: Microsoft Edge online neural TTS, edge-tts 7.3.1; English AndrewMultilingualNeural, Chinese XiaoxiaoNeural; normal rate +0%. Complete sentences are synthesized, then placed on measured timelines with deliberate 0.35–0.6 second gaps. Nothing is time-compressed or cut mid-sentence. Sentence-level subtitles, not word-level timestamps, match the measured WAV lengths. Narration is synthetic. No human listening review is claimed.

The PNGs are the unmodified original paper figures supplied by the user. SVG viewports zoom into the original pixels; outlines and traces are authored teaching annotations. Figure 1B shows text-label embeddings, not projected test images or accuracy. Figure 2 preserves decreasing-score ranks and bold exact matches; DeViSE+1K uses the 2011 ImageNet 21K label set, versus softmax’s 1K output labels. Both were trained on ILSVRC 2012 1K. The lens is fourth; both miss the exact salad-bar label; the paper describes softmax’s spacecraft labels as more nearly correct. Selected examples do not establish overall accuracy. No numerical scores are invented.

Source: Frome et al., *DeViSE: A Deep Visual-Semantic Embedding Model*, NIPS 2013, Figure 1 p.3, Figure 2 p.6, section 4.2 p.7. https://papers.nips.cc/paper/2013/hash/7cce53cf90577442771720a370c3c723-Abstract.html
TTS client: https://github.com/rany2/edge-tts

## Re-export using the included audio

Requires Node.js, Playwright/Chromium, Python with imageio-ffmpeg, and FFmpeg. Keep the archive directory structure. Serve the HTML directly for an interactive timestamp preview (`window.renderAt(t)`). For a final export from the extracted archive root:

    node work/devise-paper-videos/export-video.mjs --html work/devise-paper-videos/figure-1-en.html --out recreated-figure-1-en.mp4 --audio work/devise-paper-videos/figure-1-en/narration.wav --width 1920 --height 1080 --fps 24 --ffmpeg /path/to/ffmpeg

Set NODE_PATH to the installed Playwright package directory if needed. Substitute figure-1-zh, figure-2-en or figure-2-zh for the other versions. The exporter uses an isolated, unsigned-in Chromium, blocks external requests, checks arbitrary-order seeking, renders every frame, encodes fast-start MP4 and verifies full decoding. Actual synthesis/render times and sound levels are in production-report.json; unavailable costs/token usage are recorded as null. No credentials or intermediate frame directories are included.

For fresh narration, install edge-tts==7.3.1 and its dependencies in a virtual environment, run make-audio.py, then build-timelines.py in the original workspace. They retain sentence audio, boundary events, cue data, scripts and measured durations. build-timelines.py expects the original images under devise-presentation/public/media/originals/ and writes site transcript data under devise-presentation/src/content/.
