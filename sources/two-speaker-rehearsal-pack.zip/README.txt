DeViSE - concise bilingual scripts / 精简中英对照讲稿

Print speaker-a-bilingual-concise.pdf (slides 1-9) and
speaker-b-bilingual-concise.pdf (slides 10-19) from sources/.
Each English paragraph is immediately followed by the matching Chinese.
Every spoken paragraph is tagged with its presentation slide number.
These are web-presentation slide numbers, not paper or printed-PDF pages.
Choose ONE delivery language. Each person has a 15-minute hard limit,
including video playback, demonstrations, pauses and handover. Slide 20
and Q&A are outside the timed talk. B resets the timer at the handover.
The per-slide cumulative windows are latest checkpoints, not a reason
to fill unused time. Rehearse the delivery and finish earlier if appropriate.

打印 sources/ 内两份 bilingual-concise.pdf：一段英文，紧跟一段中文，
每段标明演示页码。A 第1-9页，B 第10-19页；每人上限15分钟，含视频。
现场只讲一种语言。第20页参考资料和问答另计。可编辑稿为同名 Markdown；
two-speaker-notes-bilingual.md 合并两人的精简中英对照内容。
早先分语种完整稿也包含在内，供需要时参考。

PDF video links open the public website. Bundled media can be played offline;
keep sources/ and media/ together for Markdown links. The overview, Figure 1
and Figure 2 clips are unchanged, 20 seconds each. Do not speak over narration.
Original evidence: Frome et al., NIPS 2013. Narration is synthesized.
Website: https://edwinleeh001.github.io/devise-presentation/
