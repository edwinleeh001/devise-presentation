DeViSE / two speakers / 15 minutes each

A covers slides 1-9 (question, model, training, inference); B covers slides 10-19
(evaluation, results, limitations and takeaways). Slide 20 is a shared reference
page, outside both timed parts. Suggested Q&A lead answers are divided by topic.

Print sources/speaker-a-en.pdf and sources/speaker-b-en.pdf for an English talk,
or the two -zh.pdf files for a Chinese talk. Languages are alternatives: do not
deliver both. Editable Markdown versions and a combined bilingual version are
included. Keep the sources/ and media/ directories together for offline links.
PDF links open the public website; bundled media can also be played offline.

Each speaker resets a personal timer and has a 15:00 hard limit: target 14:30,
plus 00:30 contingency. A can hand over early; B starts the personal timer at
the actual handover. Talk-clock columns use a conservative 15:00 handover.
A plays the overview and Figure 1 clips (40 seconds total). B plays Figure 2
(20 seconds). Videos, demonstrations, audience responses, pauses and spoken
handover are inside the budgets. Stage directions and transcribed recorded
narration are not extra presenter speech. Rehearse; keep replies brief.

双人各 15 分钟：A 讲第 1-9 页，B 讲第 10-19 页，第 20 页共用参考。
中英文是可选版本，现场选一种语言，不重复讲两遍。各自目标 14:30，
缓冲 00:30；视频、演示和交接已计入，问答另计。B 接棒时个人计时归零。

Original evidence: Frome et al., NIPS 2013, paper and official supplement.
Original figures and clips are unchanged. Narration is synthesized. Teaching
computations are not a reproduction of ImageNet training.
Website: https://edwinleeh001.github.io/devise-presentation/
