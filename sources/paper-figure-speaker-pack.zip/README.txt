DeViSE — bilingual speaker notes, original paper figures and videos — shared 28-minute Chinese/English run of show

For A4 printing, open sources/speaker-notes-zh.pdf (Chinese) or sources/speaker-notes-en.pdf (English). Both PDFs include embedded fonts, chapter timing, playback cues, recorded narration, transitions, original figures and the separate Q&A appendix. Open sources/speaker-notes-zh.md for the editable Chinese talk, sources/speaker-notes-en.md for English, or sources/speaker-notes.md for both. Both versions have matching chapter content and identical cumulative timing windows. Chapters 4 (overview), 5 (Figure 1) and 13 (Figure 2) integrate: presenter introduction, a 20-second playback cue, the exact recorded narration, follow-up explanation, an audience prompt, and a transition to the ranking loss / Table 2 and hierarchical evaluation.

Stage directions are not spoken text. During the playback cue, play the matching Chinese or English MP4 and let its narration finish before resuming. The video narration is transcribed for rehearsal; do not read it aloud over the recording. Both language versions target 28 minutes with 2 minutes of contingency inside a 30-minute hard limit. Each language’s three clips (overview, Figure 1 and Figure 2) total 60 seconds. English is estimated at 110 spoken words per minute. Chinese is estimated at about 200 characters per minute with additional reading time for foreign terms and digits; demonstrations, audience wait time and changeovers are explicitly allocated. Stage cues and recorded narration are not extra spoken text. Rehearse the cumulative deadlines; keep audience replies brief and do not replay videos. If still speaking at 28:00, go straight to the takeaways and stop by 30:00. References and Q&A follow the timed talk.

中文稿与英文稿逐章对齐，使用相同的累计时间节点。目标 28 分钟，另留 2 分钟缓冲；视频、演示、互动和换页均已计入。播放对应语言的视频，每段只播一次，不重复朗读录制旁白。

Keep the sources/ and media/ directories together so Markdown image and video links resolve offline. Each clip is exactly 20 seconds, 1080p, H.264/AAC. Original figures and their captions are unchanged. Narration is synthesized. The selected examples in Figure 2 do not establish aggregate accuracy; Table 2 values must retain their candidate set and k.

Live website: https://edwinleeh001.github.io/devise-presentation/
Method video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-1-video
Experiment video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-2-video
Source: Frome et al., NIPS 2013. Original paper and supplement are included with attribution in the notes.
