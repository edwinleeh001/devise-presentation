DeViSE — bilingual speaker notes, original paper figures and videos

Open sources/speaker-notes.md for the bilingual talk. Chapters 5 (Figure 1) and 13 (Figure 2) integrate: presenter introduction, a 20-second playback cue, the exact recorded narration, follow-up explanation, an audience prompt, and a transition to the ranking loss / Table 2 and hierarchical evaluation.

Stage directions are not spoken text. During the playback cue, play the matching Chinese or English MP4 and let its narration finish before resuming. The video narration is transcribed for rehearsal; do not read it aloud over the recording. The 20 seconds are included within the existing 2.5-minute chapter allocations. The planned talk still sums to 30 minutes; rehearse the actual pacing.

Keep the sources/ and media/ directories together so Markdown image and video links resolve offline. Each clip is exactly 20 seconds, 1080p, H.264/AAC. Original figures and their captions are unchanged. Narration is synthesized. The selected examples in Figure 2 do not establish aggregate accuracy; Table 2 values must retain their candidate set and k.

Live website: https://edwinleeh001.github.io/devise-presentation/
Method video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-1-video
Experiment video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-2-video
Source: Frome et al., NIPS 2013. Original paper and supplement are included with attribution in the notes.
