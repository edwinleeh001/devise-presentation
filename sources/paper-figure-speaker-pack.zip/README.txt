DeViSE — bilingual speaker notes, original paper figures and videos — 28-minute English run of show

Open sources/speaker-notes-en.md for the complete, polished English talk and cumulative timing table; sources/speaker-notes.md contains both languages. Chapters 5 (Figure 1) and 13 (Figure 2) integrate: presenter introduction, a 20-second playback cue, the exact recorded narration, follow-up explanation, an audience prompt, and a transition to the ranking loss / Table 2 and hierarchical evaluation.

Stage directions are not spoken text. During the playback cue, play the matching Chinese or English MP4 and let its narration finish before resuming. The video narration is transcribed for rehearsal; do not read it aloud over the recording. The English run of show targets 28 minutes with 2 minutes of contingency inside a 30-minute hard limit. All three English clips (overview, Figure 1 and Figure 2) total 60 seconds. The word budget is estimated at 110 spoken words per minute; demonstrations, audience wait time and changeovers are explicitly allocated. Stage cues and recorded narration are not extra spoken text. Rehearse the cumulative deadlines; keep audience replies brief and do not replay videos. If still speaking at 28:00, go straight to the takeaways and stop by 30:00. References and Q&A follow the timed talk.

Keep the sources/ and media/ directories together so Markdown image and video links resolve offline. Each clip is exactly 20 seconds, 1080p, H.264/AAC. Original figures and their captions are unchanged. Narration is synthesized. The selected examples in Figure 2 do not establish aggregate accuracy; Table 2 values must retain their candidate set and k.

Live website: https://edwinleeh001.github.io/devise-presentation/
Method video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-1-video
Experiment video: https://edwinleeh001.github.io/devise-presentation/#paper-figure-2-video
Source: Frome et al., NIPS 2013. Original paper and supplement are included with attribution in the notes.
